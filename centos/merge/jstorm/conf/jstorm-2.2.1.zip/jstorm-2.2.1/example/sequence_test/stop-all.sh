#!/bin/bash

jstorm jar sequence-split-merge.jar com.alibaba.jstorm.utils.KillAllTopology
